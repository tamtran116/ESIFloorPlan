$(window).bind("load", function() {
	//test address
	var loc = document.URL;
	if (loc.indexOf("list")!==-1) {
		$('#optimize').hide();
	}
	
	
	//init data table
	$('#data-table').dataTable();
	
	//Accordion init
	$(function() {
		 $( "#accordion" ).accordion({
			 heightStyle: "content",
			 collapsible: true,
//			 heightStyle: "fill"
			 });
	});
//	$(function() {
//		 $( "#accordion-resizer" ).resizable({
//		 	minHeight: 900,
//		 	minWidth: 400,
//		 	resize: function() {
//		 		$( "#accordion" ).accordion( "refresh" );
//		 	}
//		 });
//	});
	
	//get measurement for cube 
	var height = $(window).height();
	var width = $(window).width();
	var image_w;
	var image_h;
	$("<img />")
    .attr("src", "resources/images/floor03.jpg")
    .load(function() {
    	image_w = Number(this.width);
        image_h = Number(this.height);
        //alert(image_w);
        $('#minimap').attr("src","resources/images/floor03.jpg");
    });
	
	//minimap function
	$('#minimap').click(function (e) { //Relative ( to its parent) mouse position 
		var offset = $(this).offset();
		var x = Math.round(e.pageX - offset.left), y = Math.round(e.pageY - offset.top), w = image_w, h = image_h;
		$('#position').text(x + ' , ' + y);
	    map=document.getElementById('map');
	    img=document.getElementById('minimap');
	    var left=((w/img.width*x)-(map.offsetWidth/2))*-1;
	 	var top=((h/img.height*y)-(map.offsetHeight/2))*-1;
		$(document).scrollLeft(-left);
	    $(document).scrollTop(-top);
	});
	
	
	//init image area select
	$('img#map').imgAreaSelect({ 
		parent: "div#img-wrapper",
        maxWidth: 500, 
        maxHeight: 500, 
        handles: true,
        onSelectEnd: function (img, selection) {
            $('#mask-selection').fadeOut();
            $('input#cube_x1').val(selection.x1);
            $('input#cube_y1').val(selection.y1);
            $('input#cube_x2').val(selection.x2);
            $('input#cube_y2').val(selection.y2);
            $('input#cube_width').val(selection.width);
            $('input#cube_height').val(selection.height);
            $('input#cube_cx').val((selection.x1+selection.width)/2);
            $('input#cube_cy').val((selection.y1+selection.height)/2);
        }
    });
	//validate user
	var mouseHide = true;
    var role = $("h1#user_role").html().toLowerCase();
	if (role.indexOf("user")!==-1) {
    	
    	$("#accordion-resizer").html(
    			"<a href='logout'>Log Out</a>"
    	);
    	$('img#map').imgAreaSelect({ 
    		disable:true
    	});
    	mouseHide = false;
    };
	if (mouseHide) {
		$('#map').mousedown(function(){
			$('.left-wrapper').hide();
			$('#minimap').hide();
	    });
	    $('#map').mouseup(function(){
			$('.left-wrapper').fadeIn();
			$('#minimap').fadeIn();
	    });
	    $('#minimap-button').click(function() {
	    	$('#minimap').toggle();
	    });
	};
    $("a.getCloseSpots").click(function(event){
    	event.preventDefault();
    	var href = $(this).attr("href");
    	$("#img-wrapper").load( href+" #img-wrapper");
//    	alert("Data: " + data + "\nStatus: " + status);
//    	  $.get("Cindy",function(data,status){
//    		  $('html').replaceWith(data);
//    		  alert("Data: " + data + "\nStatus: " + status);
//    	  });
    	});
    $("a.getCloseSpots").button();
    
    //any cube div clickable
    $(".clickable").click(function(){
        //window.location=$(this).find("span.cube-id").html();
    	var cube_href = $(this).find("span.cube_id").html();
    	$('#update-form').load("updateCube?id="+ cube_href + " #update-form");
    	$(".cube-info").load( "cube/"+cube_href+" .cube-info");
    	$( "#accordion" ).accordion({ active: 2 });
    	$('#u-form').scrollTop( 0 );
        return false;
    });
    //make button
    $( "a.j-ui-button, button" ).button();
    
    //welcome user
    if ($('h1#user_role').text().toLowerCase().indexOf('admin') != -1) {
    	$('h1#user_role').html("Admin");
    } else if ($('h1#user_role').text().toLowerCase().indexOf('manager') != -1) {
    	$('h1#user_role').html("Manager");
    } else if ($('h1#user_role').text().toLowerCase().indexOf('user') != -1) {
    	$('h1#user_role').html("User");
    };
    
    //get previous location and put it on the map
    $.extend($.imgAreaSelect.prototype, {
        animateSelection: function (x1, y1, x2, y2, duration) {
            var fx = $.extend($('<div/>')[0], {
                ias: this,
                start: this.getSelection(),
                end: { x1: x1, y1: y1, x2: x2, y2: y2 }
            });

            $(fx).animate({
                cur: 1
            },
            {
                duration: duration,
                step: function (now, fx) {
                    var start = fx.elem.start, end = fx.elem.end,
                        curX1 = Math.round(start.x1 + (end.x1 - start.x1) * now),
                        curY1 = Math.round(start.y1 + (end.y1 - start.y1) * now),
                        curX2 = Math.round(start.x2 + (end.x2 - start.x2) * now),
                        curY2 = Math.round(start.y2 + (end.y2 - start.y2) * now);
                    fx.elem.ias.setSelection(curX1, curY1, curX2, curY2);
                    fx.elem.ias.update();
                }
            });
        }
    });
    
    $(function () {
        ias = $('img#map').imgAreaSelect({ fadeSpeed: 400, handles: true,
            instance: true });

        $('button#pre-locaton').click(function () {
            // If nothing's selected, start with a tiny area in the center
            if (!ias.getSelection().width) {
            	ias.setOptions({ show: true, x1: 199, y1: 149, x2: 200, y2: 150 });
            };
            var x1 = $('#currentx1').text();
            var y1 = $('#currenty1').text();
            var x2 = $('#currentx2').text();
            var y2 = $('#currenty2').text();
            ias.animateSelection(x1, y1, x2, y2, 'slow');
        });
    });
    
    
    
});/* end window bind */

function validateRadio (radios)
{
    for (i = 0; i < radios.length; ++ i)
    {
        if (radios [i].checked) return true;
    }
    return false;
};

function validateForm() {
	var x=document.forms["form"]["cube_id"].value;
	var y=document.forms["update-form"]["cube_id"].value;
	if (x==null || x=="" || y==null || y =="")
	{
	alert("Cube ID must be filled out");
	return false;
	};
	
	if (validateRadio(document.forms["form"]["occupied"]))
	{
		return true;
	} else if (validateRadio(document.forms["update-form"]["occupied"])) {
		return true;
	} else {
		alert("Please indicate the cube occupy status");
		return false;
	};
};
/*function updateCube() {
	var x = $('span#delCubeId').text();
	$('#update-form').load("updateCube?id="+ x + " #update-form");
	$( "#accordion" ).accordion({ active: 1 });
	$('input#cube_id').val(x);
	$('#forms').scrollTop( 0 );
}*/